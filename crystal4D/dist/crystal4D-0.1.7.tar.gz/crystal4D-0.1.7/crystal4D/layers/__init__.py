from .convSpectral import *
from .poolSpectral import *
from .convQuad import *
from .multiTaskLayer import *