# crystal4D

Package for complex convolution network and spectral pooling used for pixel-wise mapping of diffraction space images
